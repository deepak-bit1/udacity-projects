# Udacity 
Personal Blog Challenge for the Nanodegree program 

This project utilizes HTML and CSS skills to build out a personal blog website from scratch, including custom images, layout, and styling. Along with webpage design considerations, it appropriately structures my files, as well as using the proper CSS and HTML formatting & style.
The project includes; HTML files related to:
the blog website, a blog post, as well as any related CSS files for styling.
